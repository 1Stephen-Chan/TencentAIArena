﻿#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
###########################################################################
# Copyright © 1998 - 2026 Tencent. All Rights Reserved.
###########################################################################
"""
Author: Tencent AI Arena Authors

Feature preprocessor for Gorge Chase DIY agent.
"""

import math
import numpy as np

from agent_diy.conf.conf import Config


ACTION_DIRS = [
    (1, 0),   # E
    (1, -1),  # NE
    (0, -1),  # N
    (-1, -1), # NW
    (-1, 0),  # W
    (-1, 1),  # SW
    (0, 1),   # S
    (1, 1),   # SE
]


def _norm(v, v_max, v_min=0.0):
    v = float(np.clip(v, v_min, v_max))
    denom = float(v_max - v_min)
    if abs(denom) < 1e-6:
        return 0.0
    return (v - v_min) / denom


def _dir_to_vec(direction):
    table = {
        0: (0.0, 0.0),
        1: (1.0, 0.0),
        2: (1.0, -1.0),
        3: (0.0, -1.0),
        4: (-1.0, -1.0),
        5: (-1.0, 0.0),
        6: (-1.0, 1.0),
        7: (0.0, 1.0),
        8: (1.0, 1.0),
    }
    x, z = table.get(int(direction), (0.0, 0.0))
    n = math.sqrt(x * x + z * z)
    if n < 1e-6:
        return 0.0, 0.0
    return x / n, z / n


def _action_vec(action_idx):
    dx, dz = ACTION_DIRS[int(action_idx) % 8]
    n = math.sqrt(dx * dx + dz * dz)
    return dx / n, dz / n


class Preprocessor:
    def __init__(self):
        self.reset()
        self.buff_memory = {}

    def reset(self):
        self.step_no = 0
        self.max_step = 1000

    def _parse_legal_action(self, legal_act_raw):
        legal = np.ones(Config.ACTION_NUM, dtype=np.float32)
        if isinstance(legal_act_raw, (list, tuple, np.ndarray)) and len(legal_act_raw) > 0:
            first = legal_act_raw[0]
            if isinstance(first, (bool, np.bool_)):
                legal[:] = 1.0
                for i in range(min(Config.ACTION_NUM, len(legal_act_raw))):
                    legal[i] = 1.0 if bool(legal_act_raw[i]) else 0.0
            else:
                legal[:] = 0.0
                for a in legal_act_raw:
                    try:
                        idx = int(a)
                        if 0 <= idx < Config.ACTION_NUM:
                            legal[idx] = 1.0
                    except Exception:
                        continue

        if float(np.sum(legal)) <= 0.0:
            legal[:] = 1.0
        return legal

    def _extract_hero(self, frame_state, env_info):
        heroes = frame_state.get("heroes", {})
        hero_pos = heroes.get("pos", env_info.get("pos", {}))

        hero_x = float(hero_pos.get("x", 0.0))
        hero_z = float(hero_pos.get("z", 0.0))
        return heroes, hero_x, hero_z

    def _bucket_center_dist(self, bucket):
        centers = [15.0, 45.0, 75.0, 105.0, 135.0, 165.0]
        b = int(np.clip(bucket, 0, 5))
        return centers[b]

    def _build_monster_features(self, monsters, hero_x, hero_z):
        """
        建立怪物特征
        """

        feats = []
        dists = []
        monster_local = []

        for i in range(2):
            if i < len(monsters) and isinstance(monsters[i], dict):
                m = monsters[i]
                m_pos = m.get("pos", {})
                in_view = float(m.get("is_in_view", 0))
                speed = float(m.get("speed", 1.0))
                bucket = float(m.get("hero_l2_distance", 5.0))
                rel_dir = int(m.get("hero_relative_direction", 0))
                
                # 转化为方向向量
                dir_x, dir_z = _dir_to_vec(rel_dir)

                # 怪物威胁
                # 在视野范围,使用L2
                if in_view:
                    mx = float(m_pos.get("x", hero_x))
                    mz = float(m_pos.get("z", hero_z))
                    dx = mx - hero_x
                    dz = mz - hero_z
                    dist = math.sqrt(dx * dx + dz * dz)
                # 丢失视野,使用bucket
                else:
                    dist = self._bucket_center_dist(bucket)
                    dx = dir_x * dist
                    dz = dir_z * dist

                # 使用 e^(-dist/21.0) = threat
                # threat = 1.0 - _norm(dist, Config.MAP_DIAG)

                # 10维向量
                feats.extend(
                    [
                        1.0,                                        # 怪物存在标记
                        in_view,                                    # 是否视野范围内
                        _norm(dist, Config.MAP_DIAG),               # 归一化距离
                        _norm(bucket, 5.0),                         # 归一化桶距离
                        _norm(speed, Config.MAX_MONSTER_SPEED),     # 归一化速度
                        dir_x,                                      # 方向向量x
                        dir_z,                                      # 方向向量z
                        float(np.clip(dx / 20.0, -1.0, 1.0)),       # x方向距离/视野范围
                        float(np.clip(dz / 20.0, -1.0, 1.0)),       # z方向距离/视野范围
                        math.exp(-dist / 20.0),                     # 距离威胁
                    ]
                )

                dists.append(dist)
                monster_local.append({"dx": float(dx), "dz": float(dz), "speed": speed, "dist": dist})
            else:
                feats.extend([0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
                dists.append(Config.MAP_DIAG)

        return np.array(feats, dtype=np.float32), dists, monster_local

    def _build_target_features(self, organs,hero_x,hero_z,buff_refresh_time):
        """
        建立物件特征
        """

        treasures = []
        buffs = []

        for organ in organs:
            status = int(organ.get("status", 1))
            sub_type = int(organ.get("sub_type", 0))
            config_id = int(organ.get("config_id", 0))
            m_pos = organ.get("pos", {})

            rel_dir = int(organ.get("hero_relative_direction", 0))
            dir_x, dir_z = _dir_to_vec(rel_dir)
            if m_pos["x"]!= -1 and m_pos["z"] != -1:
                dx = float(m_pos["x"]) - hero_x
                dz = float(m_pos["z"]) - hero_z
                dist = math.sqrt(dx*dx + dz*dz)
            else:
                bucket = float(organ.get("hero_l2_distance", 5.0))
                dist = self._bucket_center_dist(bucket)
                dx, dz = dir_x * dist, dir_z * dist

            dist_norm = _norm(dist, Config.MAP_DIAG)

            # 宝箱特征
            if sub_type == 1:
                # 6维向量
                item = [
                    1.0,                                    # 宝箱存在标记
                    dist_norm,                              # 归一化距离
                    dir_x,                                  # 方向向量x
                    dir_z,                                  # 方向向量z
                    float(np.clip(dx / 20.0, -1.0, 1.0)),   # x方向距离/视野范围         
                    float(np.clip(dz / 20.0, -1.0, 1.0))    # z方向距离/视野范围    
                ]
                treasures.append((dist, item))

            # 加速buff特征
            elif sub_type == 2:
                if config_id not in self.buff_memory:
                    self.buff_memory[config_id] = {"last_status": status, "start_step": -1}
                mem = self.buff_memory[config_id]

                # 吃掉了buff,更新记录
                if mem["last_status"] == 1 and status == 0:
                    mem["start_step"] = self.step_no
                    
                mem["last_status"] = status

                # 计算cd
                cd_remain = 0.0
                if status == 0 and mem["start_step"] != -1:
                    elapsed_steps = self.step_no - mem["start_step"]
                    cd_remain = max(0.0, buff_refresh_time - float(elapsed_steps))

                cd_norm = _norm(cd_remain, buff_refresh_time)
                
                if status == 1:
                    dx_clip = float(np.clip(dx / 20.0, -1.0, 1.0))
                    dz_clip = float(np.clip(dz / 20.0, -1.0, 1.0))
                else:
                    dx_clip = 0.0
                    dz_clip = 0.0

                # 7维向量
                item = [
                    float(status),                         # buff存在标记
                    cd_norm,                               # cd冷却时间
                    dist_norm,                             # 归一化距离
                    dir_x,                                 # 方向向量x
                    dir_z,                                 # 方向向量z
                    dx_clip,                               # x方向距离/视野范围
                    dz_clip                                # z方向距离/视野范围
                ]
                buffs.append((dist, item))

        treasures.sort(key=lambda x: x[0])
        buffs.sort(key=lambda x: x[0])

        feat = []
        
        # 装填 4 个宝箱槽位 (4 * 6 = 24维)
        for i in range(4):
            if i < len(treasures):
                feat.extend(treasures[i][1])
            else:
                feat.extend([0.0, 1.0, 0.0, 0.0, 0.0, 0.0])
                
        # 装填 2 个 Buff 槽位 (2 * 7 = 14维)
        for i in range(2):
            if i < len(buffs):
                feat.extend(buffs[i][1])
            else:
                feat.extend([0.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0])

        nearest_treasure_vec = None
        nearest_treasure_dist_norm = 1.0
        if len(treasures) > 0:
            best_t_item = treasures[0][1]
            nearest_treasure_dist_norm = best_t_item[1]
            nearest_treasure_vec = (best_t_item[2], best_t_item[3]) 

        nearest_buff_vec = None
        nearest_buff_dist_norm = 1.0
        alive_buffs = [b for b in buffs if b[1][0] == 1.0] 
        if len(alive_buffs) > 0:
            best_b_item = alive_buffs[0][1]
            nearest_buff_dist_norm = best_b_item[2]
            nearest_buff_vec = (best_b_item[3], best_b_item[4])

        return np.array(feat, dtype=np.float32),nearest_treasure_vec, nearest_treasure_dist_norm, nearest_buff_vec, nearest_buff_dist_norm


    def _build_local_map_feature(self, map_info):
        feat = np.zeros(25, dtype=np.float32)

        if not isinstance(map_info, list) or len(map_info) == 0:
            return feat

        rows = len(map_info)
        cols = len(map_info[0]) if isinstance(map_info[0], list) else 0
        if cols <= 0:
            return feat

        center_r = rows // 2
        center_c = cols // 2

        idx = 0
        for r in range(center_r - 2, center_r + 3):
            for c in range(center_c - 2, center_c + 3):
                if 0 <= r < rows and 0 <= c < cols:
                    feat[idx] = 1.0 if float(map_info[r][c]) != 0.0 else 0.0
                idx += 1

        return feat

    def _local_passable(self, map_info, dx, dz):
        if not isinstance(map_info, list) or len(map_info) == 0:
            return True
        rows = len(map_info)
        cols = len(map_info[0]) if isinstance(map_info[0], list) else 0
        if cols <= 0:
            return True

        cr = rows // 2
        cc = cols // 2

        r = cr + int(round(dz))
        c = cc + int(round(dx))

        if 0 <= r < rows and 0 <= c < cols:
            return float(map_info[r][c]) != 0.0
        return True

    def _simulate_move(self, map_info, speed, dir_dx, dir_dz):
        cur_x, cur_z = 0.0, 0.0
        speed = max(1, int(round(speed)))

        for _ in range(speed):
            nx = cur_x + dir_dx
            nz = cur_z + dir_dz

            if abs(dir_dx) == 1 and abs(dir_dz) == 1:
                diag_ok = self._local_passable(map_info, nx, nz) and (
                    self._local_passable(map_info, cur_x + dir_dx, cur_z)
                    or self._local_passable(map_info, cur_x, cur_z + dir_dz)
                )
                if not diag_ok:
                    break
            else:
                if not self._local_passable(map_info, nx, nz):
                    break

            cur_x, cur_z = nx, nz

        return float(cur_x), float(cur_z)

    def _simulate_flash(self, map_info, dir_dx, dir_dz, max_len):
        for d in range(int(max_len), 0, -1):
            tx = dir_dx * d
            tz = dir_dz * d
            if self._local_passable(map_info, tx, tz):
                return float(tx), float(tz)
        return 0.0, 0.0

    def _estimate_action_eval(
        self,
        map_info,
        legal_action,
        hero_speed,
        monster_local,
        nearest_treasure_vec,
        nearest_treasure_dist_norm,
        nearest_buff_vec,         
        nearest_buff_dist_norm, 
        min_dist,
    ):
        safety = np.full(Config.ACTION_NUM, -1.0, dtype=np.float32)
        treasure = np.full(Config.ACTION_NUM, -1.0, dtype=np.float32)

        for act in range(Config.ACTION_NUM):
            if legal_action[act] < 0.5:
                continue

            dir_dx, dir_dz = ACTION_DIRS[act % 8]

            # 模拟落地位置
            if act < 8:
                dst_x, dst_z = self._simulate_move(map_info, hero_speed, dir_dx, dir_dz)
                moved_dist = abs(dst_x) + abs(dst_z)
            else:
                max_len = 10 if (act % 2 == 0) else 8
                dst_x, dst_z = self._simulate_flash(map_info, dir_dx, dir_dz, max_len)
                moved_dist = abs(dst_x) + abs(dst_z)

            # 计算与怪物的预判距离
            if monster_local:
                min_after = 1e9
                for m in monster_local:
                    dx = m["dx"] - dst_x
                    dz = m["dz"] - dst_z
                    d = math.sqrt(dx * dx + dz * dz) - 0.5 * float(m.get("speed", 1.0))
                    min_after = min(min_after, d)
            else:
                min_after = Config.MAP_DIAG

            # 基础安全分计算
            s = float(np.clip((min_after - 2.0) / 8.0, -1.0, 1.0))

            # 撞墙检测
            if act < 8 and moved_dist < 0.5:
                # 判断当前局势：
                if s > 0.0:
                    # 局势安全时，撞墙是愚蠢的，重罚，逼迫其探索空旷地带
                    s -= 0.35
                else:
                    # 局势极其危险时，撞墙可能是在“贴墙躲避”，轻罚或不罚，允许极限走位
                    s -= 0.05 

            # 闪现资源管理保留
            if act >= 8 and min_dist > 6.0:
                s -= 0.20

            # 多目标欲望融合
            t_raw = 0.0
            ax, az = _action_vec(act)

            # 计算宝箱吸引力
            t_treasure = 0.0
            if nearest_treasure_vec is not None:
                tx, tz = nearest_treasure_vec
                align_t = float(ax * tx + az * tz)
                dist_weight_t = float(np.clip(1.2 - nearest_treasure_dist_norm, 0.0, 1.0))
                t_treasure = align_t * dist_weight_t

            # 计算 Buff 吸引力
            t_buff = 0.0
            if nearest_buff_vec is not None:
                bx, bz = nearest_buff_vec
                align_b = float(ax * bx + az * bz)
                dist_weight_b = float(np.clip(1.2 - nearest_buff_dist_norm, 0.0, 1.0))
                # 让 AI 前期更爱吃 Buff
                buff_priority = 1.5 
                t_buff = align_b * dist_weight_b * buff_priority

            # 欲望裁决：取两者最高分（AI 会自动判断去追哪个收益更大）
            t_raw = max(t_treasure, t_buff)

            # 闪现惩罚：尽量不要用闪现去吃钱
            if act >= 8:
                t_raw *= 0.65

            # 保命压制贪婪（改进：危险时也保留一定贪婪度）
            # 原版: t = t_raw * (0.5 + 0.5 * s)  -> s=-1时t=0, s=1时t=1
            # 新版: t = t_raw * (0.65 + 0.35 * s) -> s=-1时t=0.3, s=1时t=1
            # 让AI在危险时仍有30%的宝箱欲望，鼓励"顺路吃"
            safety_clipped = float(np.clip(s, -1.0, 1.0))
            t = t_raw * (0.65 + 0.35 * safety_clipped)

            safety[act] = float(np.clip(s, -1.0, 1.0))
            treasure[act] = float(np.clip(t, -1.0, 1.0))

        return safety, treasure
    
    def feature_process(self, env_obs, last_action):

        observation = env_obs["observation"]
        # 观测信息 - 当前步数 / int32
        self.step_no = observation["step_no"]

        # 观测信息 - 帧状态数据 / FrameState
        frame_state = observation["frame_state"]

        # 观测信息 - 环境信息 / EnvInfo
        env_info = observation["env_info"]

        # 观测信息 - 局部地图信息 / int32[][]
        map_info = observation["map_info"]

        # 观测信息 - 合法动作掩码 / bool[16]
        legal_act = observation["legal_action"]

        # 环境信息 - 最大步数 max_step
        self.max_step = int(env_info.get("max_step", 1000))

        # 环境信息 - 总宝箱数量
        total_treasure = float(env_info.get("total_treasure", 10))
        
        # 环境信息 - 已收集宝箱数
        treasures_collected = int(env_info.get("treasures_collected", 0))

        # 环境信息 - 总得分
        total_score = float(env_info.get("total_score", 0.0))
             
        # 环境信息 - 步数得分
        step_score = float(env_info.get("step_score", 0.0))
        
        # 环境信息 - 宝箱得分
        treasure_score = float(env_info.get("treasure_score", 0.0))
        
        # 环境信息 - 第二怪物出现间隔
        monster_interval = int(env_info.get("monster_interval", 0))
        
        # 环境信息 - 当前已完成步数
        finished_steps = int(env_info.get("finished_steps", 0))

        # 环境信息 - 闪现技能已使用次数
        flash_count = int(env_info.get("flash_count", 0))

        # 环境信息 - 闪现冷却配置值
        flash_cooldown = float(env_info.get("flash_cooldown", 0.0))
        
        # 环境信息 - buff 总数量配置
        total_buff = float(env_info.get("total_buff", 2.0))
        
        # 环境信息 - 已获取 buff 次数
        collected_buff = int(env_info.get("collected_buff", 0))
        
        # 环境信息 - buff 刷新时间配置
        buff_refresh_time = float(env_info.get("buff_refresh_time", 0.0))
        
        # 环境信息 - 怪物速度配置值
        monster_speed = float(env_info.get("monster_speed", 1.0))

        # 解析为合法动作掩码表
        legal_action = self._parse_legal_action(legal_act)

        # 解析英雄状态 HeroState
        hero, hero_x, hero_z = self._extract_hero(frame_state, env_info)
        flash_cd = float(hero.get("flash_cooldown", 0.0))
        buff_remain = float(hero.get("buff_remaining_time", 0.0))
        
        # 英雄速度 hero_speed 根据buff_remaining_time 去判断(加速:两格/步)
        if buff_remain != 0:
            hero_speed = 2.0
        else:
            hero_speed = 1.0

        # 怪物状态 MonsterState[]
        monster_feat, monster_dists, monster_local = self._build_monster_features(
            frame_state.get("monsters", []),
            hero_x,
            hero_z,
        )
        min_dist = float(min(monster_dists)) if monster_dists else Config.MAP_DIAG
        second_dist = float(sorted(monster_dists)[1]) if len(monster_dists) > 1 else Config.MAP_DIAG

        # 物体状态列表 OrganState[]
        target_feat,nearest_treasure_vec, nearest_treasure_dist_norm, nearest_buff_vec, nearest_buff_dist_norm = self._build_target_features(
            frame_state.get("organs", []),
            hero_x,
            hero_z,
            buff_refresh_time
        )

        # 提取地图特征
        map_feat = self._build_local_map_feature(map_info)

        action_safety, action_treasure = self._estimate_action_eval(
            map_info=map_info,
            legal_action=legal_action,
            hero_speed=hero_speed,
            monster_local=monster_local,
            nearest_treasure_vec=nearest_treasure_vec,
            nearest_treasure_dist_norm=nearest_treasure_dist_norm,
            nearest_buff_vec=nearest_buff_vec,         
            nearest_buff_dist_norm=nearest_buff_dist_norm, 
            min_dist=min_dist,
        )

        # 英雄特征
        self_feat = np.array(
            [
                _norm(hero_x, Config.MAP_SIZE),
                _norm(hero_z, Config.MAP_SIZE),
                _norm(float(self.step_no), float(max(1, self.max_step))),
                _norm(flash_cd, Config.MAX_FLASH_CD),
                _norm(buff_remain, Config.MAX_BUFF_DURATION),
                _norm(hero_speed, Config.MAX_MONSTER_SPEED),
                _norm(float(treasures_collected), max(1.0, total_treasure)),
                _norm(min_dist, Config.MAP_DIAG),
            ],
            dtype=np.float32,
        )

        action_eval_feat = np.concatenate([action_safety, action_treasure]).astype(np.float32)

        # 总特征
        feature = np.concatenate(
            [
                self_feat,
                monster_feat,
                target_feat,
                map_feat,
                legal_action.astype(np.float32),
                action_eval_feat,
            ]
        )

        remain_info = {
            "step_no": int(self.step_no),
            "hero_x": hero_x,
            "hero_z": hero_z,
            "min_monster_dist": min_dist,
            "second_monster_dist": second_dist,
            "treasure_cnt": treasures_collected,
            "buff_cnt": collected_buff,
            "flash_cnt": flash_count,
            "step_score": step_score,
            "treasure_score": treasure_score,
            "total_score": total_score,
            "action_safety": action_safety.tolist(),
            "action_treasure": action_treasure.tolist(),
            "last_action": int(last_action) if last_action is not None else -1,
        }
        return feature, legal_action.tolist(), remain_info