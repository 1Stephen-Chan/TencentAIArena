#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
###########################################################################
# Copyright © 1998 - 2026 Tencent. All Rights Reserved.
###########################################################################
"""
Author: Tencent AI Arena Authors

Best model tracker for saving and loading highest-score models.
"""

import os
import json


class BestModelTracker:
    """
    追踪全局最优模型（适配 kaiwudrl 框架分布式模式）

    功能：
    1. 每N局检查一次是否出现新的最高分
    2. 维护一个best_model_info.json记录最高分信息
    3. 追踪全局最优的 checkpoint_id，而不是立即保存
    4. 支持延迟保存：等待框架保存后再复制最优模型

    注意：
    - 在 kaiwudrl 分布式模式下，模型由 learner 自动保存到模型池
    - aisrv 通过 model_file_sync 自动从模型池拉取最新模型
    - 此类追踪全局最优 checkpoint_id，并在合适时机触发保存
    """

    def __init__(self, model_path, check_interval=50, logger=None, min_improvement=0.0):
        """
        Args:
            model_path: 模型保存路径
            check_interval: 每多少局检查一次最高分（默认50局）
            logger: 日志对象
            min_improvement: 最小改进阈值（默认0.0，任何提升都算）
        """
        self.model_path = model_path
        self.check_interval = check_interval
        self.logger = logger
        self.min_improvement = min_improvement

        self.info_file = os.path.join(model_path, "best_model_info.json")

        # 加载历史最高分信息
        self.best_info = self._load_best_info()

        # 当前窗口内的得分记录
        self.recent_scores = []
        self.recent_episodes = []

        # 全局最优追踪（跨窗口）
        self.global_best_score = self.best_info.get("best_score", -999999.0)
        self.global_best_checkpoint_id = self.best_info.get("checkpoint_id")

    def _load_best_info(self):
        """加载历史最高分信息"""
        if os.path.exists(self.info_file):
            try:
                with open(self.info_file, 'r', encoding='utf-8') as f:
                    info = json.load(f)
                    if self.logger:
                        self.logger.info(
                            f"Loaded best model info: score={info.get('best_score', 0):.1f} "
                            f"at episode={info.get('episode', 0)}"
                        )
                    return info
            except Exception as e:
                if self.logger:
                    self.logger.warning(f"Failed to load best_model_info.json: {e}")

        return {
            "best_score": -999999.0,
            "episode": 0,
            "avg_score": 0.0,
            "total_reward": 0.0,
            "timestamp": "",
            "checkpoint_id": None,  # 记录对应的 checkpoint ID（从 training_metrics 获取）
        }

    def _save_best_info(self):
        """保存最高分信息到JSON"""
        try:
            os.makedirs(self.model_path, exist_ok=True)
            with open(self.info_file, 'w', encoding='utf-8') as f:
                json.dump(self.best_info, f, indent=2, ensure_ascii=False)
        except Exception as e:
            if self.logger:
                self.logger.error(f"Failed to save best_model_info.json: {e}")

    def record_episode(self, episode_num, score, total_reward, checkpoint_id=None):
        """
        记录一局的得分

        Args:
            episode_num: 局数
            score: 游戏得分（sim_score）
            total_reward: 累计奖励
            checkpoint_id: 当前的 checkpoint ID（可选，从 training_metrics 获取）
        """
        self.recent_scores.append(score)
        self.recent_episodes.append({
            "episode": episode_num,
            "score": score,
            "total_reward": total_reward,
            "checkpoint_id": checkpoint_id,
        })

        # 每check_interval局检查一次
        if len(self.recent_scores) >= self.check_interval:
            return self._check_and_update_best()

        return False

    def _check_and_update_best(self):
        """
        检查最近N局的平均分是否超过全局最高

        Returns:
            bool: 是否需要保存新的最高分模型
        """
        if not self.recent_scores:
            return False

        # 计算最近N局的平均分
        avg_score = sum(self.recent_scores) / len(self.recent_scores)
        max_score = max(self.recent_scores)

        # 找到最高分对应的episode信息
        best_episode_info = max(self.recent_episodes, key=lambda x: x["score"])

        should_save = False
        reason = ""

        # 策略：平均分超过全局最高（带最小改进阈值）
        if avg_score > self.global_best_score + self.min_improvement:
            should_save = True
            reason = f"avg_score improved: {self.global_best_score:.1f} -> {avg_score:.1f}"

            # 更新全局最优
            self.global_best_score = avg_score
            self.global_best_checkpoint_id = best_episode_info.get("checkpoint_id")

        if should_save:
            import time
            self.best_info = {
                "best_score": float(avg_score),
                "max_score": float(max_score),
                "episode": int(best_episode_info["episode"]),
                "avg_score": float(avg_score),
                "total_reward": float(best_episode_info["total_reward"]),
                "checkpoint_id": best_episode_info.get("checkpoint_id"),
                "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
                "window_size": len(self.recent_scores),
            }
            self._save_best_info()

            if self.logger:
                checkpoint_info = f"checkpoint_id={best_episode_info.get('checkpoint_id')}" if best_episode_info.get('checkpoint_id') else "checkpoint_id=unknown"
                self.logger.info(
                    f"[GLOBAL BEST] {reason} | "
                    f"episode={best_episode_info['episode']} | "
                    f"max={max_score:.1f} avg={avg_score:.1f} | "
                    f"{checkpoint_info}"
                )

        # 清空窗口
        self.recent_scores.clear()
        self.recent_episodes.clear()

        return should_save

    def get_best_score(self):
        """获取历史最高分"""
        return self.best_info.get("best_score", -999999.0)

    def get_best_episode(self):
        """获取最高分对应的局数"""
        return self.best_info.get("episode", 0)

    def get_best_checkpoint_id(self):
        """获取全局最高分对应的 checkpoint ID"""
        return self.global_best_checkpoint_id

    def get_global_best_score(self):
        """获取全局最高分（跨所有窗口）"""
        return self.global_best_score

    def should_save_current_model(self, current_score, current_checkpoint_id):
        """
        实时判断当前模型是否应该保存为最优模型

        Args:
            current_score: 当前得分
            current_checkpoint_id: 当前 checkpoint ID

        Returns:
            bool: 是否应该保存
        """
        if current_score > self.global_best_score + self.min_improvement:
            self.global_best_score = current_score
            self.global_best_checkpoint_id = current_checkpoint_id
            return True
        return False
